<?php
$DSN='mysql:host = localhost; dbname=route_news_blog';
$ConnectingDB = new PDO($DSN,'root','');
?>
